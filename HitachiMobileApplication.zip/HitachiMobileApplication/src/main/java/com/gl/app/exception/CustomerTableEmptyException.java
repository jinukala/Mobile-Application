package com.gl.app.exception;

public class CustomerTableEmptyException  extends RuntimeException{
	public CustomerTableEmptyException(String message) {
		super(message);
	}
	

}
